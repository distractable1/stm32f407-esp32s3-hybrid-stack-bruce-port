"""Regression checks for the launcher's APP and full-flash file formats."""

import struct
import unittest
import zlib

import package_launcher as packaging


def image_at(address, length=256, stack=0x2001FF00):
    image = bytearray(b"\xA5" * length)
    struct.pack_into("<II", image, 0, stack, address + 9)
    return bytes(image)


def with_header_field(package, offset, value):
    altered = bytearray(package)
    struct.pack_into("<I", altered, offset, value)
    struct.pack_into("<I", altered, 56, zlib.crc32(altered[:56]) & 0xFFFFFFFF)
    return bytes(altered)


class LauncherPackageTests(unittest.TestCase):
    def setUp(self):
        self.launcher = image_at(packaging.FLASH_BASE)
        self.application = image_at(packaging.APP_BASE)
        self.package = packaging.package_app(self.application)

    def test_round_trip_and_header_layout(self):
        self.assertEqual(packaging.validate_package(self.package), self.application)
        fields = packaging.HEADER.unpack_from(self.package)
        self.assertEqual(fields[:5], (0x31505041, 1, 0x54313030, 0x08020000, 256))
        self.assertEqual(fields[5], zlib.crc32(self.application))
        self.assertEqual(fields[6], b"USB Synth".ljust(32, b"\0"))
        self.assertEqual(fields[7], zlib.crc32(self.package[:56]))
        self.assertEqual(fields[8], 0x434F4D54)

    def test_combined_layout_and_erased_padding(self):
        combined = packaging.combine_images(self.launcher, self.application)
        packaging.validate_combined(combined, len(self.launcher))
        self.assertEqual(len(combined), 0x100000)
        self.assertEqual(combined[:256], self.launcher)
        self.assertEqual(combined[0x20000:0x20100], self.application)
        self.assertEqual(combined[0xFFFC0:], self.package[:64])
        self.assertEqual(set(combined[256:0x20000]), {0xFF})
        self.assertEqual(set(combined[0x20100:0xFFFC0]), {0xFF})

    def test_supported_stack_boundaries(self):
        for stack in (0x20000008, 0x2001FF00, 0x10000008, 0x10010000):
            with self.subTest(stack=stack):
                packaging.package_app(image_at(packaging.APP_BASE, stack=stack))

    def test_invalid_stack_and_reset_vectors(self):
        for stack in (0, 0x20000000, 0x10000000, 0x2001FF08, 0x20020000, 0x20020008, 0x10010008, 0x20000104):
            with self.subTest(stack=stack), self.assertRaises(ValueError):
                packaging.package_app(image_at(packaging.APP_BASE, stack=stack))
        for reset in (packaging.APP_BASE + 1, packaging.APP_BASE + 8, packaging.FLASH_BASE + 9,
                      packaging.APP_BASE - 1, packaging.APP_BASE + 257):
            altered = bytearray(self.application)
            struct.pack_into("<I", altered, 4, reset)
            with self.subTest(reset=reset), self.assertRaises(ValueError):
                packaging.package_app(bytes(altered))

    def test_invalid_launcher_is_rejected(self):
        with self.assertRaises(ValueError):
            packaging.combine_images(image_at(packaging.APP_BASE), self.application)
        with self.assertRaises(ValueError):
            packaging.combine_images(image_at(packaging.FLASH_BASE, 0x20001), self.application)

    def test_size_boundaries_and_no_overlap(self):
        app = image_at(packaging.APP_BASE, packaging.APP_LIMIT)
        launcher = image_at(packaging.FLASH_BASE, packaging.LAUNCHER_LIMIT)
        combined = packaging.combine_images(launcher, app)
        packaging.validate_combined(combined, len(launcher))
        for size in (0, 7, packaging.APP_LIMIT + 1):
            with self.subTest(size=size), self.assertRaises(ValueError):
                packaging.package_app(b"\0" * size)

    def test_bad_header_fields_even_with_correct_header_crc(self):
        for offset, value in ((0, 0), (4, 2), (8, 0), (12, 0x08000000),
                              (16, 0), (16, packaging.APP_LIMIT + 1), (60, 0)):
            with self.subTest(offset=offset, value=value), self.assertRaises(ValueError):
                packaging.validate_package(with_header_field(self.package, offset, value))

    def test_header_and_payload_crc_failures(self):
        header = bytearray(self.package)
        header[30] ^= 1
        with self.assertRaisesRegex(ValueError, "header CRC"):
            packaging.validate_package(header)
        payload = bytearray(self.package)
        payload[100] ^= 1
        with self.assertRaisesRegex(ValueError, "payload CRC"):
            packaging.validate_package(payload)

    def test_truncated_and_extra_bytes(self):
        for package in (self.package[:40], self.package[:-1], self.package + b"\0"):
            with self.subTest(length=len(package)), self.assertRaises(ValueError):
                packaging.validate_package(package)

    def test_valid_crc_cannot_hide_an_invalid_vector(self):
        payload = bytearray(self.application)
        struct.pack_into("<I", payload, 4, packaging.FLASH_BASE + 9)
        package = bytearray(self.package[:64] + payload)
        struct.pack_into("<I", package, 20, packaging.crc32(payload))
        struct.pack_into("<I", package, 56, packaging.crc32(package[:56]))
        with self.assertRaisesRegex(ValueError, "reset vector"):
            packaging.validate_package(package)

    def test_combined_damage_is_rejected(self):
        good = packaging.combine_images(self.launcher, self.application)
        for offset in (300, 0x20080, 0x30000, 0xFFFC0 + 56):
            bad = bytearray(good)
            bad[offset] ^= 1
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                packaging.validate_combined(bad, len(self.launcher))
        with self.assertRaises(ValueError):
            packaging.validate_combined(good[:-1], len(self.launcher))


if __name__ == "__main__":
    unittest.main(verbosity=2)
