"""Check the actual ARM ELF load regions, startup symbols and exported bytes."""
from pathlib import Path
import struct

def verify(folder,name,binary,base,limit,ram_code=False):
    elf=Path('outputs',folder,'Debug',name+'.elf').read_bytes()
    raw=Path('outputs',binary+'.bin').read_bytes()
    header=struct.unpack_from('<16sHHIIIIIHHHHHH',elf)
    assert header[0][:6]==b'\x7fELF\x01\x01'
    assert header[2]==40
    assert 8<=len(raw)<=limit
    stack,reset=struct.unpack_from('<II',raw)
    assert stack==0x2001ff00 and reset&1 and base+8<=(reset&~1)<base+len(raw)
    ram_segments=0
    for i in range(header[10]):
        kind,offset,vaddr,paddr,filesz,memsz,flags,align=struct.unpack_from('<8I',elf,header[5]+i*header[9])
        if kind!=1 or not memsz:continue
        assert filesz<=memsz
        assert flags&7!=7
        if 0x20000000<=vaddr<0x20020000:
            assert vaddr+memsz<=0x2001ff00
            if flags&1:ram_segments+=1
        elif 0x10000000<=vaddr<0x10010000:
            assert vaddr+memsz<=0x10010000
        else:assert base<=vaddr and vaddr+memsz<=base+limit
        if filesz:
            assert base<=paddr and paddr+filesz<=base+len(raw)
            assert raw[paddr-base:paddr-base+filesz]==elf[offset:offset+filesz]
    if ram_code:assert ram_segments==1
    sections=[struct.unpack_from('<10I',elf,header[6]+i*header[11]) for i in range(header[12])]
    symbols={}
    for section in sections:
        if section[1]!=2:continue
        names=sections[section[6]]
        strings=elf[names[4]:names[4]+names[5]]
        for offset in range(section[4],section[4]+section[5],section[9]):
            key,value,size,info,other,index=struct.unpack_from('<IIIBBH',elf,offset)
            end=strings.find(b'\0',key)
            symbols[strings[key:end].decode()]=value
    assert symbols['g_pfnVectors']==base
    assert symbols['_estack']==0x2001ff00
    assert symbols['_ebss']<0x2001fb00
    if ram_code:
        for symbol in ['flash_wait','flash_erase','flash_word']:
            assert symbols['_sramfunc']<=(symbols[symbol]&~1)<symbols['_eramfunc']
        assert base<=symbols['_siramfunc']<base+len(raw)
    print(f'{name}: checked {len(raw)} flash bytes, SRAM load bounds, vectors and ELF flags')

verify('launcher-project','STM32 SD Launcher','stm32-sd-launcher',0x08000000,0x20000,True)
verify('synth-launcher-app','STM32 Synth App','stm32-synth-launcher-app',0x08020000,0xdffc0)
verify('touch-launcher-app','STM32 Touch App','stm32-touch-launcher-app',0x08020000,0xdffc0)
