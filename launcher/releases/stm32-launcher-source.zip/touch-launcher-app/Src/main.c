#include "board_support.h"
#include <stdio.h>

static void draw(void){
    rectangle(0,0,320,240,BLACK);
    text(8,8,"TOUCH TEST APP",CYAN);
    panel_button(224,0,88,"MENU",0);
    text(8,42,board_was_inherited()?"Using launcher LCD / touch / SD":"Board initialized locally",WHITE);
    text(8,66,"Calibration supplied by launcher",WHITE);
    text(8,197,"KEY0 held: recalibrate",WHITE);
    text(8,218,"Hold WK_UP: launcher",WHITE);
    board_status_line(0,0,0,0,0);
}
int main(void){
    if(!board_init())for(;;){}
    draw();int oldx=-1,oldy=-1;
    for(;;){
        unsigned buttons=physical_buttons();
        if(buttons&1){board_recalibrate();draw();oldx=oldy=-1;}
        if(buttons&8)board_return_to_launcher();
        int x,y;
        if(board_touch(&x,&y)){
            if(y<30 && x>=224)board_return_to_launcher();
            if(y>=95 && y<185){
                if(oldx>=0)rectangle(oldx-2,oldy-2,5,5,BLACK);
                rectangle(x-2,y-2,5,5,CYAN);oldx=x;oldy=y;
            }
            char line[39];snprintf(line,sizeof(line),"Touch X:%d Y:%d",x,y);
            board_status_line(8,166,line,WHITE,BLACK);
        }
        delay_ms(5);
    }
}
