/*
 * SPDX-FileCopyrightText: Copyright (c) 2024 Ha Thach (tinyusb.org)
 * SPDX-License-Identifier: MIT
 *
 * This file is part of the TinyUSB stack.
 */

#ifndef TUSB_DWC2_COMMON_H
#define TUSB_DWC2_COMMON_H

#include "common/tusb_common.h"
#include "dwc2_type.h"

#if CFG_TUD_ENABLED
#include "device/dcd.h"
#endif

#if CFG_TUH_ENABLED
#include "host/hcd.h"
#endif

/* Following symbols must be defined by port header
  - _dwc2_controller[]: array of controllers
  - DWC2_EP_MAX: largest EP counts of all controllers
  - dwc2_clock_init(): clock init call before
  - dwc2_phy_init/dwc2_phy_update: phy init called before and after core reset
  - dwc2_phy_deinit(dwc2, hs_phy_type): phy deinit to disable PHY power, only deinit the phy used by core
  - dwc2_int_set(rhport, role, enabled): required for device and host
  - dwc2_remote_wakeup_delay
*/

#if defined(TUP_USBIP_DWC2_STM32)
  #include "dwc2_stm32.h"
#elif defined(TUP_USBIP_DWC2_ESP32)
  #include "dwc2_esp32.h"
#elif TU_CHECK_MCU(OPT_MCU_GD32VF103)
  #include "dwc2_gd32.h"
#elif TU_CHECK_MCU(OPT_MCU_BCM2711, OPT_MCU_BCM2835, OPT_MCU_BCM2837)
  #include "dwc2_bcm.h"
#elif TU_CHECK_MCU(OPT_MCU_EFM32GG)
  #include "dwc2_efm32.h"
#elif TU_CHECK_MCU(OPT_MCU_XMC4000)
  #include "dwc2_xmc.h"
#elif defined(TUP_USBIP_DWC2_AT32)
  #include "dwc2_at32.h"
#elif defined(TUP_USBIP_DWC2_NRF)
  #include "dwc2_nrf.h"
#elif defined(TUP_USBIP_DWC2_APM32)
  #include "dwc2_apm32.h"
#elif defined(TUP_USBIP_DWC2_IFX)
  #include "dwc2_ifx.h"
#else
  #error "Unsupported MCUs"
#endif

enum {
  DWC2_CONTROLLER_COUNT = TU_ARRAY_SIZE(_dwc2_controller)
};

enum {
  OTG_INT_COMMON = 0 // GINTSTS_DISCINT | GINTSTS_CONIDSTSCHNG
};

//--------------------------------------------------------------------+
// Core/Controller
//--------------------------------------------------------------------+
TU_ATTR_ALWAYS_INLINE static inline dwc2_regs_t* DWC2_REG(uint8_t rhport) {
  if (rhport >= DWC2_CONTROLLER_COUNT) {
    // user mis-configured, ignore and use first controller
    rhport = 0;
  }
  return (dwc2_regs_t*)_dwc2_controller[rhport].reg_base;
}

// check if highspeed phy should be used
bool dwc2_core_is_highspeed_phy(dwc2_regs_t* dwc2, bool prefer_hs_phy);
bool dwc2_core_init(uint8_t rhport, bool is_hs_phy, bool is_dma);
void dwc2_core_deinit(uint8_t rhport);
void dwc2_core_handle_common_irq(uint8_t rhport, bool in_isr);

//--------------------------------------------------------------------+
// DFIFO
//--------------------------------------------------------------------+
TU_ATTR_ALWAYS_INLINE static inline void dfifo_flush_tx(dwc2_regs_t* dwc2, uint8_t fnum) {
  // flush TX fifo and wait for it cleared
  dwc2->grstctl = GRSTCTL_TXFFLSH | (fnum << GRSTCTL_TXFNUM_Pos);
  while (0 != (dwc2->grstctl & GRSTCTL_TXFFLSH_Msk)) {}
}

TU_ATTR_ALWAYS_INLINE static inline void dfifo_flush_rx(dwc2_regs_t* dwc2) {
  // flush RX fifo and wait for it cleared
  dwc2->grstctl = GRSTCTL_RXFFLSH;
  while (0 != (dwc2->grstctl & GRSTCTL_RXFFLSH_Msk)) {}
}

void dfifo_read_packet(dwc2_regs_t* dwc2, uint8_t* dst, uint16_t len);
void dfifo_write_packet(dwc2_regs_t* dwc2, uint8_t fifo_num, uint8_t const* src, uint16_t len);

//--------------------------------------------------------------------+
// DMA
//--------------------------------------------------------------------+

#endif
