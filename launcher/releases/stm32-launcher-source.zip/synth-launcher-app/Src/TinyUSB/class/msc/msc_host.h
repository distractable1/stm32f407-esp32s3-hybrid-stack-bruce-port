/*
 * SPDX-FileCopyrightText: Copyright (c) 2019 Ha Thach (tinyusb.org)
 * SPDX-License-Identifier: MIT
 *
 * This file is part of the TinyUSB stack.
 */

#ifndef TUSB_MSC_HOST_H_
#define TUSB_MSC_HOST_H_

#include "msc.h"

#ifdef __cplusplus
extern "C" {
#endif

//--------------------------------------------------------------------+
// Class Driver Configuration
//--------------------------------------------------------------------+

#ifndef CFG_TUH_MSC_MAXLUN
  #define CFG_TUH_MSC_MAXLUN 4
#endif

typedef struct {
  const msc_cbw_t *cbw;       // SCSI command
  const msc_csw_t *csw;       // SCSI status
  void            *scsi_data; // SCSI Data
  uintptr_t        user_arg;  // user argument
} tuh_msc_complete_data_t;

typedef bool (*tuh_msc_complete_cb_t)(uint8_t dev_addr, const tuh_msc_complete_data_t *cb_data);

//--------------------------------------------------------------------+
// Application API
//--------------------------------------------------------------------+

// Check if device supports MassStorage interface.
// This function true after tuh_msc_mounted_cb() and false after tuh_msc_unmounted_cb()
bool tuh_msc_mounted(uint8_t dev_addr);

// Check if the interface is currently ready or busy transferring data
bool tuh_msc_ready(uint8_t dev_addr);

// Get the LUN count the device reported, clamped to CFG_TUH_MSC_MAXLUN
uint8_t tuh_msc_get_maxlun(uint8_t dev_addr);

// Get number of block, as cached during enumeration (LUN 0 only). 0 for a LUN not below tuh_msc_get_maxlun()
uint32_t tuh_msc_get_block_count(uint8_t dev_addr, uint8_t lun);

// Get block size in bytes, as cached during enumeration (LUN 0 only). 0 for a LUN not below tuh_msc_get_maxlun()
uint32_t tuh_msc_get_block_size(uint8_t dev_addr, uint8_t lun);

// Perform a full SCSI command (cbw, data, csw) in non-blocking manner.
// Complete callback is invoked when SCSI op is complete.
// return true if success, false if the interface is not configured, cbw->lun is not below tuh_msc_get_maxlun(),
// or there is already pending operation. The commands below also return false in these cases.
// NOTE: buffer must be accessible by USB/DMA controller, aligned correctly and multiple of cache line if enabled
bool tuh_msc_scsi_command(uint8_t daddr, const msc_cbw_t *cbw, void *data, tuh_msc_complete_cb_t complete_cb,
                          uintptr_t arg);

// Perform SCSI Inquiry command
// Complete callback is invoked when SCSI op is complete.
// NOTE: response must be accessible by USB/DMA controller, aligned correctly and multiple of cache line if enabled
bool tuh_msc_inquiry(uint8_t dev_addr, uint8_t lun, scsi_inquiry_resp_t *response, tuh_msc_complete_cb_t complete_cb,
                     uintptr_t arg);

// Perform SCSI Test Unit Ready command
// Complete callback is invoked when SCSI op is complete.
bool tuh_msc_test_unit_ready(uint8_t dev_addr, uint8_t lun, tuh_msc_complete_cb_t complete_cb, uintptr_t arg);

// Perform SCSI Request Sense 10 command
// Complete callback is invoked when SCSI op is complete.
// NOTE: response must be accessible by USB/DMA controller, aligned correctly and multiple of cache line if enabled
bool tuh_msc_request_sense(uint8_t dev_addr, uint8_t lun, void *response, tuh_msc_complete_cb_t complete_cb,
                           uintptr_t arg);

// Perform SCSI Read 10 command. Read n blocks starting from LBA to buffer
// Complete callback is invoked when SCSI op is complete.
// NOTE: buffer must be accessible by USB/DMA controller, aligned correctly and multiple of cache line if enabled
bool tuh_msc_read10(uint8_t dev_addr, uint8_t lun, void *buffer, uint32_t lba, uint16_t block_count,
                    tuh_msc_complete_cb_t complete_cb, uintptr_t arg);

// Perform SCSI Write 10 command. Write n blocks starting from LBA to device
// Complete callback is invoked when SCSI op is complete.
// NOTE: buffer must be accessible by USB/DMA controller, aligned correctly and multiple of cache line if enabled
bool tuh_msc_write10(uint8_t dev_addr, uint8_t lun, const void *buffer, uint32_t lba, uint16_t block_count,
                     tuh_msc_complete_cb_t complete_cb, uintptr_t arg);

// Perform SCSI Read Capacity 10 command
// Complete callback is invoked when SCSI op is complete.
// Note: during enumeration, host stack already carried out this request. Application can retrieve capacity by
// simply call tuh_msc_get_block_count() and tuh_msc_get_block_size()
bool tuh_msc_read_capacity(uint8_t dev_addr, uint8_t lun, scsi_read_capacity10_resp_t *response,
                           tuh_msc_complete_cb_t complete_cb, uintptr_t arg);

//------------- Application Callback -------------//

// Invoked when a device with MassStorage interface is mounted
void tuh_msc_mount_cb(uint8_t dev_addr);

// Invoked when a device with MassStorage interface is unmounted
void tuh_msc_umount_cb(uint8_t dev_addr);

//--------------------------------------------------------------------+
// Internal Class Driver API
//--------------------------------------------------------------------+

bool     msch_init(void);
bool     msch_deinit(void);
uint16_t msch_open(uint8_t rhport, uint8_t dev_addr, const tusb_desc_interface_t *desc_itf, uint16_t max_len);
bool     msch_set_config(uint8_t daddr, uint8_t itf_num);
void     msch_close(uint8_t dev_addr);
bool     msch_xfer_cb(uint8_t dev_addr, uint8_t ep_addr, xfer_result_t event, uint32_t xferred_bytes);

#ifdef __cplusplus
}
#endif

#endif
