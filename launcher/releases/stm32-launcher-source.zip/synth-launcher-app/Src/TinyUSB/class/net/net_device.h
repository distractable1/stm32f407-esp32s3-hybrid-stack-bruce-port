/*
 * SPDX-FileCopyrightText: Copyright (c) 2020 Peter Lawrence
 * SPDX-FileCopyrightText: Copyright (c) 2019 Ha Thach (tinyusb.org)
 * SPDX-License-Identifier: MIT
 *
 * This file is part of the TinyUSB stack.
 */

#ifndef TUSB_NET_DEVICE_H_
#define TUSB_NET_DEVICE_H_

#include <stdint.h>
#include "class/cdc/cdc.h"

#if CFG_TUD_ECM_RNDIS && CFG_TUD_NCM
#error "Cannot enable both ECM_RNDIS and NCM network drivers"
#endif

/* Maximum Transmission Unit (in bytes) of the network, including Ethernet header */
#ifndef CFG_TUD_NET_MTU
#define CFG_TUD_NET_MTU           1514
#endif

// Link speed in bit/s reported to the host, 0 = USB bus speed.
// One value for both directions: Linux and Microsoft's NCM sample read the two speed fields in opposite order.
#ifndef CFG_TUD_NET_LINK_BITRATE
#define CFG_TUD_NET_LINK_BITRATE  0
#endif


// Table 4.3 Data Class Interface Protocol Codes
typedef enum
{
  NCM_DATA_PROTOCOL_NETWORK_TRANSFER_BLOCK = 0x01
} ncm_data_interface_protocol_code_t;

// Table 5.2 bmNetworkCapabilities bits
typedef enum {
  NCM_NETWORK_CAPS_NONE              = 0x00,
  NCM_NETWORK_CAPS_ETH_FILTER        = (1 << 0),
  NCM_NETWORK_CAPS_NET_ADDRESS       = (1 << 1),
  NCM_NETWORK_CAPS_ENCAP_COMMAND     = (1 << 2),
  NCM_NETWORK_CAPS_MAX_DATAGRAM_SIZE = (1 << 3),
  NCM_NETWORK_CAPS_CRC_MODE          = (1 << 4),
  NCM_NETWORK_CAPS_NTB_INPUT_SIZE    = (1 << 5)
} ncm_network_capabilities_t;

#ifdef __cplusplus
 extern "C" {
#endif

//--------------------------------------------------------------------+
// Implemented by Application
//--------------------------------------------------------------------+
#if CFG_TUD_ECM_RNDIS
extern void rndis_class_set_handler(uint8_t *data, int size);
#endif

//--------------------------------------------------------------------+
// Application API
//--------------------------------------------------------------------+

// indicate to network driver that client has finished with the packet provided to network_recv_cb()
void tud_network_recv_renew(void);

// poll network driver for its ability to accept another packet to transmit
bool tud_network_can_xmit(uint16_t size);

// if network_can_xmit() returns true, network_xmit() can be called once
void tud_network_xmit(void *ref, uint16_t arg);

//--------------------------------------------------------------------+
// Application Callbacks (WEAK is optional)
//--------------------------------------------------------------------+

// client must provide this: return false if the packet buffer was not accepted
bool tud_network_recv_cb(const uint8_t *src, uint16_t size);

// client must provide this: copy from network stack packet pointer to dst
uint16_t tud_network_xmit_cb(uint8_t *dst, void *ref, uint16_t arg);

//------------- ECM/RNDIS -------------//

// Optional: invoked once per configuration when the data endpoints open (RNDIS: on
// SET_CONFIGURATION, ECM: first SET_INTERFACE alt 1), to reset network state
void tud_network_init_cb(void);

// client must provide this: 48-bit MAC address
// TODO removed later since it is not part of tinyusb stack
extern uint8_t tud_network_mac_address[6];

//------------- NCM -------------//

// Optional callback: informs the application about host requested packet filter bits
void tud_network_set_packet_filter_cb(uint16_t packet_filter);

// Optional callback: called during netd_init() to get the initial link state.
// Override to return the actual physical link state instead of the compile-time default.
bool tud_network_default_link_state_cb(void);

// Set the network link state (up/down) and notify the host
void tud_network_link_state(uint8_t rhport, bool is_up);

//--------------------------------------------------------------------+
// INTERNAL USBD-CLASS DRIVER API
//--------------------------------------------------------------------+
void     netd_init            (void);
bool     netd_deinit          (void);
void     netd_reset           (uint8_t rhport);
uint16_t netd_open            (uint8_t rhport, tusb_desc_interface_t const * itf_desc, uint16_t max_len);
bool     netd_control_xfer_cb (uint8_t rhport, uint8_t stage, tusb_control_request_t const * request);
bool     netd_xfer_cb         (uint8_t rhport, uint8_t ep_addr, xfer_result_t result, uint32_t xferred_bytes);
void     netd_report          (uint8_t *buf, uint16_t len);

#ifdef __cplusplus
 }
#endif

#endif /* TUSB_NET_DEVICE_H_ */
